﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Hosting;
using System.Net;
using System.IO;
using System.Reflection;

namespace SimpleHost
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string physicalDir = Directory.GetCurrentDirectory();
                
                if (!(physicalDir.EndsWith("\\")))
                        physicalDir = physicalDir + "\\";
 
                // Copy this hosting DLL into the /bin directory of the application
                string FileName = Assembly.GetExecutingAssembly().Location;
                Console.WriteLine(FileName);
                try
                {
                    if (!Directory.Exists(physicalDir + "bin\\"))
                        Directory.CreateDirectory(physicalDir + "bin\\");
             
                    string JustFname = Path.GetFileName(FileName);
                    File.Copy(FileName, physicalDir + "bin\\" + JustFname, true);
                }
                catch { ;}                
                
                HttpListenerWrapper lw = (HttpListenerWrapper)ApplicationHost.CreateApplicationHost(
                    typeof(HttpListenerWrapper), "/", physicalDir);
    
                string[] prefixes = new string[] {
                    "http://localhost:8081/",
                    "http://127.0.0.1:8081/"
                };
                lw.Configure(prefixes, "/", Directory.GetCurrentDirectory());
                lw.Start();
                Console.WriteLine("Listening for requests on http://localhost:8081/");
                while (true)
                    lw.ProcessRequest();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                Console.ReadLine();
            }
        }
    }
}
